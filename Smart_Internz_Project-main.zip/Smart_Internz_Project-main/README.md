# Smart_Internz_Project

1) Sahara Shrestha - Model Building
2) Rajiv Nair - Video Analysis
3) Mohamad Al Saeed - Twilio SMS Integration 
4) Salini Pradhan - IBM Cloud

Dataset: https://drive.google.com/file/d/186AUNIXBQUA-iifhHmmojFda-bS1dJ5w/view?usp=sharing
